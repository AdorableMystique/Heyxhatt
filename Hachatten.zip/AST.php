<?php

function extractCommands(ast\Node $node): array {

    $results = [];

    $execFunctions = [
        'exec','system','passthru','shell_exec','proc_open','popen','pcntl_exec'
    ];

    $fileWrites = [
        'file_put_contents','fwrite','fopen','unlink','rename','copy',
        'chmod','chown','mkdir','rmdir'
    ];

    $dynamicExec = [
        'assert','create_function'
    ];

    $walk = function($node) use (&$walk, &$results, $execFunctions, $fileWrites, $dynamicExec) {

        if (!$node instanceof ast\Node) return;

        $line = $node->lineno ?? null;
        $kind = $node->kind;
        $name = strtolower(ast\get_kind_name($kind));
        $name = preg_replace('/^ast_/', '', $name);
        /* ------------------------------------
           Direct execution constructs
        ------------------------------------ */

        if ($kind === ast\AST_INCLUDE_OR_EVAL) {

            $flag = resolveFlag($kind, $node->flags);

            /* remove exec_ prefix */
            $flag = str_ireplace('exec_', '', $flag);
            $flag = str_ireplace('ast\\flags\\', '', $flag);
            
            $results[] = [
                //'Category' => 'direct_execution',
                'Name' => strtolower($flag),
                'Line' => $line
            ];
        }

        /* ------------------------------------
           Output
        ------------------------------------ */

        if ($kind === ast\AST_ECHO || $kind === ast\AST_PRINT) {

            $results[] = [
                //'Category' => 'output',
                'Name' => str_ireplace('ast_', '', $name),
                'Line' => $line
            ];
        }

        /* ------------------------------------
           Shell operators (`cmd`)
        ------------------------------------ */

        if ($kind === ast\AST_SHELL_EXEC) {

            $results[] = [
                //'Category' => 'shell_operator',
                'Name' => 'shell_exec_operator',
                'Line' => $line
            ];
        }

        /* ------------------------------------
           Function calls
        ------------------------------------ */

        if ($kind === ast\AST_CALL) {

            $expr = $node->children['expr'];

            /* dynamic function call */
            if (!$expr instanceof ast\Node || $expr->kind !== ast\AST_NAME) {

                $results[] = [
                    //'Category' => 'dynamic_function_call',
                    'Name' => 'dynamic_call',
                    'Line' => $line
                ];
            }

            /* normal named call */
            if ($expr instanceof ast\Node && $expr->kind === ast\AST_NAME) {

                $func = strtolower($expr->children['name']);

                if (in_array($func, $execFunctions)) {

                    $results[] = [
                        //'Category' => 'generic_execution',
                        'Name' => $func,
                        'Line' => $line
                    ];

                } elseif (in_array($func, $fileWrites)) {

                    $results[] = [
                        //'Category' => 'file_write',
                        'Name' => $func,
                        'Line' => $line
                    ];

                } elseif (in_array($func, $dynamicExec)) {

                    $results[] = [
                       // 'Category' => 'dynamic_code_execution',
                        'Name' => $func,
                        'Line' => $line
                    ];

                } else {

                    $results[] = [
                        //'Category' => 'function_call',
                        'Name' => $func,
                        'Line' => $line
                    ];
                }
            }
        }

        /* ------------------------------------
           Recurse
        ------------------------------------ */

        foreach ($node->children as $child) {

            if ($child instanceof ast\Node) {
                $walk($child);
            }

            if (is_array($child)) {
                foreach ($child as $sub) {
                    if ($sub instanceof ast\Node) {
                        $walk($sub);
                    }
                }
            }
        }
    };

    $walk($node);
    if (in_array("echo",$results,true)){
        echo "keyword found";
    }
    return $results;
}


/* ------------------------------------
   Flag resolver (same as yours)
------------------------------------ */

function resolveFlag($kind, $flagValue) {

    $meta = ast\get_metadata()[$kind] ?? null;

    if (!$meta || empty($meta->flags)) return (string)$flagValue;

    $names = [];

    foreach ($meta->flags as $constName) {

        $val = constant($constName);

        if ($meta->flagsCombinable) {

            if ($flagValue & $val)
                $names[] = basename($constName);

        } elseif ($flagValue === $val) {

            return basename($constName);
        }
    }

    return $names ? implode('|', $names) : (string)$flagValue;
}


/*
function extractCommands(ast\Node $node): array {
    $results = [];
    $line = property_exists($node, 'line') ? $node->line : null;
    $walk = function(ast\Node $node) use (&$walk, &$results) {
        $line = $node->lineno ?? null;

        // If current node has no line, use first child with a line
        if ($line === null) {
            foreach ($node->children as $child) {
                if ($child instanceof ast\Node && isset($child->lineno)) {
                    $line = $child->lineno;
                    break;
                }
            }
        }
        echo "line : ".$line." ";
        $kind = $node->kind;
        print_r( ast\get_metadata()[$kind]);

        /*
        $name=strtolower(ast\get_kind_name($kind) ?? "");
        $name=str_ireplace("ast_","",$name);
        $name=explode("\\", $name);
        $name=$name[count($name)-1];
        $flag=strtolower(resolveFlag($node->kind,  $node->flags) ?? "");
        $flag=str_ireplace("ast_","",$flag);
        $flag=explode("|", $flag);
        foreach($flag as $Key => $Flag){
            $Flag = explode("\\", $Flag);
            $flag[$Key] = $Flag[count($Flag)-1];
        }
        
        //$results[] = ['Name' => $name, 'Flags' => $flag, 'Line' => $line];

        // Recurse into children
        foreach ($node->children as $child) {
            if ($child instanceof ast\Node) {
                $walk($child);
            } elseif (is_array($child)) {
                foreach ($child as $subChild) {
                    if ($subChild instanceof ast\Node) {
                        $walk($subChild);
                    }
                }
            }
        }
    };

    $walk($node);

    return $results;
}



function resolveFlag($kind, $flagValue) {
    $meta = ast\get_metadata()[$kind] ?? null;
    if (!$meta || empty($meta->flags)) return (string)$flagValue;

    $names = [];
    foreach ($meta->flags as $constName) {
        $val = constant($constName); // Get the int value of the flag (e.g. 16)
        
        if ($meta->flagsCombinable) {
            if ($flagValue & $val) $names[] = basename($constName);
        } elseif ($flagValue === $val) {
            return basename($constName); // Return immediately for exclusive flags
        }
    }
    return $names ? implode(' | ', $names) : (string)$flagValue;
}*/
?>