<?php
// Tasks:

/*
build template for Jodit Editor
Create Account App
Create file space app

*/

// Häxhatt by Monica Hart
// --Häxhatten fångar Loke (The witch's Hat captures Loki)
//-----------------------------------------------------------------------------
// Most PHP plugin systems trust third‑party code and try to recover at runtime. 
// I built a system that assumes every plugin is hostile and denies execution 
// unless it passes static and runtime policy checks.
//
// Enjoy Häxhatten - Monica Hart
//
// ©2025 Monica Hart

interface RenderablePage {
    public function Menu(); // uppercase M to match the mainSequence expectation
    public function SecondaryMenu();// uppercase M to match the mainSequence expectation
    public function Body();
    public function Head();
    public function Footer();
    public function Title();
    public function Script();    
}
    
$sequence;

class StandardFunctions{
    public $templatePath="templates";                                          //the subfolder where we will hold templates
    public $defaultTemplate="FreyjaOne";                                         //the exact folder where the index template resides 
    public $SQLScriptPath="SQLScripts";
    public $JavaScriptsPath="JavaScripts";
    public $appPath="apps";                                                     //Applications to load automatically
    public $localizationPath="localization";                                    //set the path to the localization files
    public $logDir="logs";
    //Localization
    public $locError = [];
    public $DefaultLang="sv";

     final public function GetImageFromHTML ($string){
        preg_match_all("/<img\b[^>]*>/i", $string, $Matches, PREG_SET_ORDER);
        foreach($Matches as $i => $Match){
            echo $Match[0] . PHP_EOL;
        }
    }

    final public function error($Code, $input1, $input2, ...$argsList){
        //$sequence=$this->sequence;
        $logDir = __DIR__ . "/" . $this->logDir;
        if (!file_exists($logDir)) {
            if (!mkdir($logDir, 0775, true)) {
                die("Failed to create log directory: $logDir");
            }
        }

        $err = $this->locError[$Code] ?? "<b>Unknown Error:</b><br/>Error code {$Code} reported with inputs.";

        $err=str_ireplace("%Code%", $Code, $err);
        $err=str_ireplace("%input1%", $input1, $err);
        $err=str_ireplace("%input2%", $input2, $err);

        if (count($argsList)>0){
            foreach($argsList as $k => $v){
                 $err = str_ireplace("%input" . ($k + 3) . "%", $v, $err);
            }
        }

        switch($Code){// For extra error processing
            default:    //Nothing should error to a default leave blank
                break;
        }
        if (strlen($err)>2){
       
            if (file_exists(__DIR__."/".$this->logDir)==false)
                mkdir(__DIR__ . "/".$this->logDir, 0777, true);

        }else{
            $err="<b>Zero length error:<b><br/>, an error was reported but no information was included. Message reads code: {$Code}, input1: {$input1}, input2: {$input2}";
        }
        if (strlen($this->Error )>2){
             $this->Error .= "<br/><br/>".$err;
        }else{
             $this->Error=$err;
        }
        $err=str_ireplace("<b>","",$err);
        $err=str_ireplace("</b>","",$err);
        $err=str_ireplace("<br/>","",$err);
        $err="[".date("m-d-y H:i:s")."] ".$err;
        $errLog =__DIR__."/".$this->logDir."/log_".date("m-d-y",time()).".log";
        file_put_contents($errLog,$err . PHP_EOL,FILE_APPEND);
        /*if (ob_get_level()) {//clear the buffer of unauthorized output
            ob_end_clean();
        }*/
    }


    //--------------------------------------------------SQL Functions------------------------------------------------------------

    public function DBConnect(){                                //used to create a per app connection
        $sequence=$this->sequence;
        if ($this->addConnection===true){
            $sequence->sqlService = "mysql:host=$this->host;dbname=$this->db;charset=$this->charset";
            try {
                return new PDO($this->sqlService, $this->user, $this->pass, $this->SQLOptions);
            } catch (PDOException $e) {
                $this->error(2, $e->getMessage(), (int)$e->getCode());
            }
        }
    }

    public function SQLQuery($ConnectionNumber, $QueryFileName, ...$QueryVariables){
        try {
            $file = __DIR__ . "/" . $this->SQLScriptPath. "/" . $QueryFileName . ".sql";
            $pdo = $this->Database[$ConnectionNumber] ?? null;
            if (is_null($pdo)){
                $this->error(4, "No database connection available, please addjust '".get_class($this)."' and related plugins.", $ConnectionNumber);
                return false;
            }elseif (file_exists($file)&&(is_dir($file)==false)){       //Check to see if the file exists and is not a directory
                $f = trim(file_get_contents($file));                           //Get the SQL File Contents, $f is short for File Contents, you'll see this through out the script
                
                $stmt = $pdo->prepare($f);                              //Get ready to process the filee
                if (!$stmt) {
                    $this->error(11, $QueryFileName, null);             //Something went wrong and now it's pulling an error to display.
                    return false;
                }else{
                    foreach ($QueryVariables as $k=>$v){
                        $stmt->bindValue(':'.$k, $v, PDO::PARAM_STR);   //Set up the variables to look for and insert them into the FileContents
                    }
                    $stmt->execute(); //Run the query
                    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);       //Get the results
                    return $results;
                }
            }else {
                $this->error(0, $file, ""); // Missing File
                return false;
            }
        }catch (PDOException $e) {
                $this->error(12, $QueryFileName, $e->getMessage());     // There was some other PDO exception, tells the error prrocessor to show a message and log the error
                return false;
        }
    }

    public function SQLExecute($ConnectionNumber, $QueryFileName, ...$QueryVariables){
        try {
            $file = __DIR__ . "/" . $this->SQLScriptPath. "/" . $QueryFileName . ".sql";
            $pdo = $this->Database[$ConnectionNumber] ?? null;
            if (is_null($pdo)){
                $this->error(4, "No database connection available, please addjust '".get_class($this)."' and related plugins.", $ConnectionNumber);
                return false;
            }elseif (file_exists($file)&&(is_dir($file)==false)){       //Check to see if the file exists and is not a directory
                $f = trim(file_get_contents($file));                           //Get the SQL File Contents, $f is short for File Contents, you'll see this through out the script
                $stmt = $pdo->prepare($f);                              //Get ready to process the filee
                if (!$stmt) {
                    $this->error(11, $QueryFileName, null);             //Something went wrong and now it's pulling an error to display.
                    return false;
                }else{
                    foreach ($QueryVariables as $k=>$v){
                        $stmt->bindValue(':'.$k, $v, PDO::PARAM_STR);   //Set up the variables to look for and insert them into the FileContents
                    }
                    $stmt->execute(); //Run the query
                    return true;
                }
            }else {
                $this->error(0, $file, ""); // Missing File
                return false;
            }
        }catch (PDOException $e) {
                $this->error(12, $QueryFileName, $e->getMessage());     // There was some other PDO exception, tells the error prrocessor to show a message and log the error
                return false;
        }
    }
}
class mainSequence extends StandardFunctions {

    private $sequence;                                                          //Parent Opject
    
    //Application pathing and array initiallization
   
    private $host = 'localhost';
    private $appList = [];



    //Variables related to the end processing and display of the Ui
    private $Methods= ["Menu", "SecondaryMenu", "Body","Head","Footer","Title","Script"];
    private $filteredTags=["<html","<body", "<head","<link rel", "<style","</style>","<script>","</script>"];
    private $addConnection=true;
    private $Menu="";
    private $SecondaryMenu="";
    private $Error="";
    private $Body="";
    private $Head="";
    private $Footer="";
    private $Title="";
    private $Meta="";
    private $Icon="";
    private $Script="";
    public $containerUI = "";

    //Database Variables
    private $filteredFunctions = [
    "eval", "include", "file_get_contents", "file_put_contents", "copy", "chown", "spl_autoload_register",
    "call_user_func", "call_user_func_array", "forward_static_call", "curl_exec",
    "stream_socket_client", "fsockopen", "file", "curl_multi_exec", "ob_get_contents",
    "ob_get_clean", "http_response_code", "flush", "dl", "header", "setcookie",
    "ignore_user_abort", "set_time_limit", "ini_set", "putenv", "getenv", "ini_restore",
    "ReflectionFunction", "ReflectionClass", "readfile", "touch", "scandir", "glob",
    "chmod", "rename", "unlink", "fwrite", "fopen", "include_once", "require_once",
    "pcntl_exec", "popen", "proc_open", "assert", "exec", "passthru", "shell_exec",
    "system", "preg_replace", "create_function", "echo", "print_r", "require", "die",
    "exit", "obj_clean", "obj_start", "obj_end", "obj_flush"
    ];
    //Data base Variables
    private $DBConfig = "var/config";
    public $UseDB = false;
    private $db = 'DataBase';
    private $user = 'User';
    private $pass = 'Password!';
    private $charset = 'utf8mb4';
    public $Database = [];

    private $sqlService;                                                         // = "mysql:host=$host;dbname=$db;charset=$charset";

    private $SQLOptions = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // throw exceptions on errors
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // fetch results as associative arrays
        PDO::ATTR_EMULATE_PREPARES   => false,                  // use real prepared statements
    ];

    public $dataBaseConnections=[];

    //--------------------------------------------------------------Error Logging--------------------------------


   



    private function filteredPHPFunctions($file){              //Get PHP File and check for disallowed code
        $file=file_get_contents($file);
        $arr =  $this->filteredFunctions;
        $out=[true, null, null, null];

        foreach($arr as $k=>$v){
            if($out[0]==true){
                $vLines=explode("\n", $file);
                foreach($vLines as $K=>$V){
                    $n=stripos($V,$v);

                    if ($n !== false){
                        $out=array(false, $K+1, $n, $file, $v);

                        break;
                    }
                }
            }
        }
        return $out;
    }

    private function filteredHTMLtags($string){              //filter output
        if (!is_string($string)) {

            return [false, 0, 0, 'non-string output'];
        }
        $out=array(true, null, null, null);
        foreach($this->filteredTags as $k=>$v){
            if($out[0]==true){
                $vLines=explode("\n", $string);
                 foreach($vLines as $K=>$V){
                    $n=stripos($V, $v);
                    if ($n !== false){
                        $out=array(false, $K+1, $n,  htmlspecialchars($v));
                        break;
                    }
                }
            }
        }
        return $out;
    }
    // ------- CONSTRUCTION--------------
    public function __construct($sequence) {
        $this->sequence = $sequence ?? $this;
        $this->UseDB = true;

        $iniArray = parse_ini_file("/{$this->DBConfig}.ini");
        foreach($iniArray as $k => $v){
            $this->$k = $v;
        }
        
    }
    //----Execution
    final public function Execute(){
        //this->GetImageFromHTML("!2345 6567 <img src=\"1234\" height=\"123\" width=\"400\"> a noob a way");



        $this->sequence = $this;
        
        //Start localization
        $lang = strtolower(substr($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'en', 0, 5));
        $file = __DIR__ . "/" . $this->localizationPath . "/" . $lang . "_error.txt";

        if (file_exists($file)==false){
            $file = __DIR__ . "/" . $this->localizationPath . "/{$this->DefaultLang}_error.txt";
            if (file_exists($file)==false){
                die("Unable to load default localization file. Please reinstall \"{$file}\"");
            }
        }
        $locError=file_get_contents($file);
            $this->locError=explode("\n",$locError);

        //begin Database stuff
        $this->Database[0] = $this->DBConnect();

        //Main application execution section.
        $FN=__DIR__."/".$this->templatePath."/".$this->defaultTemplate."/index.html";   //retrieve the base file

        $this->containerUI=file_get_contents($FN);                                //main html template

        $this->ButtonFile=__DIR__."/".$this->templatePath."/".$this->defaultTemplate."/MenuButton.tpl";//Button File Location

        if (file_exists($this->ButtonFile)){
            $lines = file($this->ButtonFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $this->ButtonFile = array_map('trim', $lines);//set button file array
        }else{
            $this->error(0, $this->ButtonFile, "");
        }

        $appFiles=scandir(__DIR__."/".$this->appPath);                            //get the list of apps
        unset($appFiles[0],$appFiles[1]);

        foreach($appFiles as $k => $v){
            ob_start();
            $f=__DIR__."/".$this->appPath."/".$v;
            $class=pathinfo($v, PATHINFO_FILENAME);
            $Extension = pathinfo($v, PATHINFO_EXTENSION);

            if (file_exists($f)){
               
                if ($Extension!=="inc"){
                    //intensionally left blank
                    
                }elseif (!is_dir($f)){                                           //we only want to do something if it is a file. Otherwise it can still loop
                    
                    //$class=$class[0];

                    $this->appList[$v]['file']=file_get_contents($f);
                    
                    $err=$this->filteredPHPFunctions($f);                           //set the error array
                    if ($err[0]==false){
                        $this->error(3,$err[1],$err[2],$class, $f, $err[4]);                    //<code>, <line>, <character>
                    }else{
                        set_time_limit(1);           // seconds
                        ini_set('memory_limit', '64M');

                        require_once($f);
                         if (class_exists($class)){
                            try{
                               $this->appList[$v]['obj']=new $class($this);
                               $obj=$this->appList[$v]['obj'];
                               if (isset($obj->UseDB)){
                                    if ($obj->UseDB==true)
                                        $obj->Database[0]=$this->DBConnect();
                               }

                                foreach ($this->Methods as $K => $Method){ ///Loop through the list of Methods in out main object
                                    ob_start();
                                    if (method_exists($this->appList[$v]['obj'], $Method)){//check if method exists in our new object
                                        $Output=call_user_func(array($this->appList[$v]['obj'], $Method));//call the method
                                            
                                            if (empty($Output)){// recode as switch... maybe using $if (empty($Output)){\n $$output="Empty";}
                                                //no output do nothing
                                            }elseif ($Method==="Script"){ // Array keys are as follows FileName(string) and Hideen (Bool)
                                                if (in_array("<iframe", array_map( "strtolower", $this->filteredTags))){
                                                    $this->error(17, null, null);
                                                }elseif (is_array($Output)==false){
                                                    $variable=$this->captureVarDump($Output);
                                                    $this->error(16, "Array",$class, $Method, gettype($Output), $f, $variable);
                                                }elseif(empty($Output['FileName'])){
                                                    $this->error(13, $class, $Method);
                                                }else{
                                                    $file = __DIR__ . "/" . $this->JavaScriptsPath . "/" . $Output['FileName']. ".html";
                                                    if (file_exists($file)){
                                                        $file = __DIR__ . "/" . $this->JavaScriptsPath . "/" . $Output['FileName']. ".html";
                                                            $Hidden = !empty($Output['Hidden']) ? 'hidden' : '';
                                                            $script = "<div id=\"{$class}-DIV\" class=\"SandBox\" {$Hidden}><p class=\"subtitle\">{$class}</p><iframe class=\"SandBox-iframe\" src=\"{$this->JavaScriptsPath}/{$Output['FileName']}.html\" sandbox=\"allow-scripts allow-same-origin\"></iframe></div>";

                                                        if (strlen($this->Script)<1){
                                                            $this->Script=$script;
                                                        }else{
                                                            $this->Script.=$script;
                                                        }
                                                        
                                                    }else{
                                                        $this->error(1, $file, "");
                                                    }
                                                }
                                                $this->output($class, $Method, $this->Script);//cal0l the method and store the output
                                            }elseif (($Method=="Menu")||($Method=="SecondaryMenu")){

                                                if (is_array($Output)){

                                                    foreach($Output as $MenuNo => $MenuArray){
                                                        $str=$this->captureVarDump($Output);

                                                       
                                                        if (gettype($MenuArray)=="array"){// Buttons need to select a line in the button file to choose from. a Location, and a URL Title and each one is denoted in the apps output array buy those exact keys.
                                                            if ((gettype($MenuArray["Select"])!=="integer")||(gettype($MenuArray["Location"])!=="string")||(gettype($MenuArray["URL Title"])!=="string")){
                                                                
                                                                if (gettype($MenuArray["Select"])!=="integer"){
                                                                    $this->error(16, "Integer",$class, $Method, gettype($Output), $f, $str);
                                                                }
                                                                if (gettype($MenuArray["Location"])!=="string"){
                                                                    
                                                                    $this->error(16, "String",$class, $Method, gettype($Output), $f, $MenuArray[1]);
                                                                }
                                                                if (gettype($MenuArray["URL Title"])!=="string"){
                                                                     $this->error(16, "String",$class, $Method, gettype($Output), $f, $MenuArray[2]);
                                                                }
                                                            }else{
                                                                //set the buttton
                                                                $Button=$this->ButtonFile[$MenuArray["Select"]];
                                                                $Button=str_ireplace("%Location%", $MenuArray["Location"], $Button);
                                                                $Button=str_ireplace("%URL Title%", $MenuArray["URL Title"], $Button);
                                                                

                                                                if (strlen($this->$Method)<2){  //create and add button to the menu
                                                                    $this->$Method=$Button;
                                                                    
                                                                }else{
                                                                    $this->$Method.= "<br/>".$Button;
                                                                }
                                                            }
                                                        }else{
                                                            $this->error(15, $class, $Method, gettype($Output), $f, $this->captureVarDump($Output)) ;
                                                        }
                                                    }
                                                }else{
                                                    $this->error(15, $class, $Method, gettype($Output), $f, $this->captureVarDump($Output)) ;
                                                }
                                            }elseif (gettype($Output)=="string"){
                                                $this->Output($class, $Method, $Output);
                                            }else{
                                                $this->error(14, $class, $Method, gettype($Output), $f);
                                            }
                                        
                                    }else{
                                        $this->error(7, $class, $Method, $f); //Send error code, class name, function name
                                    }
                                    ob_end_clean();
                                }
                            }catch(Throwable $phpError){
                                $this->error(4,$phpError->getMessage(),null, $phpError->getFile() . PHP_EOL, $phpError->getLine() . PHP_EOL); 
                            }

                        }else{
                            $this->error(6, $class, $f);
                        }
                    }
                }else{
                    //the file being a directory is not an error, we just don't need to do anything with it.
                    continue;
                }
            }else{
                $this->error(0,$f,null);
                continue;
            }
        }

        //replace tags in template as defined by "%menu%, %body%,%head%,%footer%, %title%, %meta%, %icon%, %script%"
        $this->containerUI=str_ireplace("%menu%",$this->Menu,$this->containerUI);
        $this->containerUI=str_ireplace("%SecondaryMenu%",$this->SecondaryMenu,$this->containerUI);
        $this->containerUI=str_ireplace("%body%",$this->Body,$this->containerUI);
        $this->containerUI=str_ireplace("%error%",$this->Error,$this->containerUI);
        $this->containerUI=str_ireplace("%head%",$this->Head,$this->containerUI);
        $this->containerUI=str_ireplace("%footer%",$this->Footer,$this->containerUI);
        $this->containerUI=str_ireplace("%title%",$this->Title,$this->containerUI);
        $this->containerUI=str_ireplace("%meta%",$this->Meta,$this->containerUI);
        $this->containerUI=str_ireplace("%icon%",$this->Icon,$this->containerUI);
        $this->containerUI=str_ireplace("%script%",$this->Script,$this->containerUI);
    }
    //Loke says hi
    private function Output($Class, $Method, $String){
        parse_str($_SERVER['QUERY_STRING'], $URLQuery);
       
                  
        if ($Method === "Menu"){
            
            if (strlen($this->{$Method})>1){
                $this->{$Method}.="<br/>".$String;//call the method
            }else{
                $this->{$Method}.=$String;//call the method
            }
        }else if (!empty($URLQuery['app']) && $URLQuery['app'] == $Class){
           
            if (strlen($this->{$Method})>1){
                $this->{$Method}.="<br/>".$String;//call the method
            }else{
                $this->{$Method}=$String;//call the method
            }
        }
    }
    public function Menu(){ // uppercase M to match the mainSequence expectation

    }
    public function SecondaryMenu(){ // uppercase M to match the mainSequence expectation

    }
    public function Body(){

    }
    public function Head(){
            
    }
    public function Footer(){

    }
    public function Title(){

    }
    public function Script(){
            
    }

}
$sequence = new mainSequence(null);
$sequence->Execute();
echo $sequence->containerUI;

//Ebbity-ebbity That's all folks.
// ?>