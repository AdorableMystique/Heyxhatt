<?php
// Generate a large, obfuscated PHP test file
$stressFile = 'stress_test.php';
$fh = fopen($stressFile, 'w');

fwrite($fh, "<?php\n");

// Repeat risky patterns many times
for ($i = 0; $i < 1000; $i++) {
    // Normal risky function
    fwrite($fh, "eval('echo $i;');\n");

    // Dynamic variable/function
    fwrite($fh, "\${'ev'.'al'}('echo $i;');\n");

    // Base64 encoded payload
    $payload = base64_encode("echo 'payload $i';");
    fwrite($fh, "eval(base64_decode('$payload'));\n");

    // Hex-encoded string
    $hexPayload = '';
    $str = "echo 'hex $i';";
    for ($j = 0; $j < strlen($str); $j++) {
        $hexPayload .= '\\x' . dechex(ord($str[$j]));
    }
    fwrite($fh, "eval('$hexPayload');\n");

    // Concatenated function name
    fwrite($fh, "${'a'.'s'.'s'.'e'.'r'.'t'}('1');\n");
}

fwrite($fh, "?>");
fclose($fh);

echo "Stress test file generated: $stressFile\n";