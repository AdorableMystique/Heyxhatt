<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

use PhpParser\Lexer;
use PhpParser\Parser\Php7;
use PhpParser\Node;
use PhpParser\NodeTraverser;
use PhpParser\NodeVisitorAbstract;

// Load the PHP file to analyze
$code = file_get_contents('index.php');

// Autoloader for PhpParser
spl_autoload_register(function ($class) {
    $prefix = 'PhpParser\\';
    $base_dir = '/var/www/html/PHP-Parser-5.7.0/lib/PhpParser/';
    $len = strlen($prefix);

    if (strncmp($prefix, $class, $len) !== 0) return;

    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

    if (file_exists($file)) {
        require $file;
    }
});

// Create parser
$lexer = new Lexer();
$parser = new Php7($lexer);

try {
    $ast = $parser->parse($code);
} catch (PhpParser\Error $e) {
    die('Parse error: ' . $e->getMessage());
}

// Define risky functions
$risky = [
    'eval','assert','system','shell_exec','exec','passthru','create_function','preg_replace','echo'
];

// AST visitor
class RiskyVisitor extends NodeVisitorAbstract {
    private static array $risky = [];

    public function __construct(array $risky) {
        self::$risky = $risky;
    }

    public function enterNode(Node $node) {

        // 1️⃣ Detect direct function calls
        if ($node instanceof Node\Expr\FuncCall) {
            $name = $node->name;

            if ($name instanceof Node\Name) {
                $func = strtolower($name->toString());
                if (in_array($func, self::$risky)) {
                    echo "⚠ Detected direct risky function call: $func on line {$node->getLine()}\n";
                }
            }
            // 2️⃣ Dynamic function via variable
            elseif ($name instanceof Node\Expr\Variable) {
                echo "⚠ Detected dynamic function call via variable on line {$node->getLine()}\n";
            }
            // 3️⃣ Concatenated/obfuscated function names
            elseif ($name instanceof Node\Expr\BinaryOp\Concat) {
                echo "⚠ Detected concatenated/obfuscated function call on line {$node->getLine()}\n";
            }
        }

        // 4️⃣ Detect language constructs

        foreach (self::$risky as $Key => $Value) {
            $className = "PhpParser\\Node\\Stmt\\{$Value}_";

            if ($node instanceof $className) {
                echo "⚠ Detected {$Value} statement on line {$node->getLine()}\n";
            }
        }
        /*if ($node instanceof Node\Expr\Echo_) {
            echo "⚠ Detected print statement on line {$node->getLine()}\n";
        }
        if ($node instanceof Node\Expr\Print_) {
            echo "⚠ Detected print statement on line {$node->getLine()}\n";
        }
        f ($node instanceof Node\Expr\Exit_) {
            echo "⚠ Detected die/exit statement on line {$node->getLine()}\n";
        }

        // 5️⃣ Detect dynamic variables ($$var)
        if ($node instanceof Node\Expr\Variable && $node->name instanceof Node\Expr) {
            echo "⚠ Detected dynamic variable on line {$node->getLine()}\n";
        }*/

        // 6️⃣ Detect common obfuscation: eval(base64_decode(...))
        if ($node instanceof Node\Expr\FuncCall &&
            $node->name instanceof Node\Name &&
            strtolower($node->name->toString()) === 'eval') {

            if (!empty($node->args)) {
                $arg = $node->args[0]->value;
                if ($arg instanceof Node\Expr\FuncCall &&
                    $arg->name instanceof Node\Name &&
                    strtolower($arg->name->toString()) === 'base64_decode') {
                    echo "⚠ Detected eval(base64_decode(...)) pattern on line {$node->getLine()}\n";
                }
            }
        }
    }
}

// Traverse AST
$traverser = new NodeTraverser();
$traverser->addVisitor(new RiskyVisitor($risky));
$traverser->traverse($ast);

echo "✅ Scan complete.\n";
?>