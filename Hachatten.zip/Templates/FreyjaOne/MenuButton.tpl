The following contains a list of buttons with URL types. Haxhatt expects you to choose one as it will not let you define your own buttons in php
<div class="Menu Label">%URL Title%</div>
<div class="Menu-Item" Loc=-5 Offset=5 Move=10 MoveSwitch=False onclick="window.location.href='index.php?app=%location%'" title="go to %location%">%URL Title%</div>
<div class="Menu-Item" Loc=-5 Offset=5 Move=10 MoveSwitch=False onclick="window.location.href='http://%location%'" title="go to %URL Title% outside the website">%URL Title%</div>
<div class="Menu-Item" Loc=-5 Offset=5 Move=10 MoveSwitch=False onclick="window.location.href='https://%location%'" title="go to %URL Title% which is outside the website">%URL Title%</div>
<div class="Menu-Item" Loc=-5 Offset=5 Move=10 MoveSwitch=False onclick="window.location.href='ftp://%location%'" title="get file from %URL Title%">%URL Title%</div>
<div class="SecondaryMenuLabel">%URL Title%</div>
<div class="SecondaryMenu-Item" Loc=-5 Offset=5 Move=10 MoveSwitch=False onclick="window.location.href='index.php?app=%location%'" title="go to %location%">%URL Title%</div>
<div class="SecondaryMenu-Item" Loc=-5 Offset=5 Move=10 MoveSwitch=False onclick="window.location.href='http://%location%'" title="go to %URL Title% outside the website">%URL Title%</div>
<div class="SecondaryMenu-Item" Loc=-5 Offset=5 Move=10 MoveSwitch=False onclick="window.location.href='https://%location%'" title="go to %URL Title% which is outside the website">%URL Title%</div>
<div class="SecondaryMenu-Item" Loc=-5 Offset=5 Move=10 MoveSwitch=False onclick="window.location.href='ftp://%location%'" title="get file from %URL Title%">%URL Title%</div>
