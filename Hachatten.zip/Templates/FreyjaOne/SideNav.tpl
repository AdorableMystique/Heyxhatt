<div id="Menu-Item"><a href="%input0%" alt="%input3%"><div class="MenuItem"><image height=20 src="apps/images/%input1%"<p>%input2%</p></div></a>
</div><br/>