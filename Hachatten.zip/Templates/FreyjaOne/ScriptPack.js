

var Menu = document.getElementById("Menu-Outer");
var MenuBody = document.getElementById("Menu-Body");
var MenuButton = document.getElementById("Menu-Button");
var MenuPackage = document.getElementById("Menu-Package");

document.addEventListener("DOMContentLoaded", () => {
    Menu = document.getElementById("Menu-Outer");
    MenuBody = document.getElementById("Menu-Body");
    MenuButton = document.getElementById("Menu-Button");
    MenuPackage = document.getElementById("Menu-Package");

    MoveItSetup();
});

// Initialize as an empty array
var MoveObjects = [];
var GlowObjects = [];
const isMobile = /Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent);

function MoveItSetup() {
    // Reset MoveObjects with the main Menu object
	var i=0;
	i = 1;
	if (!MenuBody.style.left) {
    	MenuBody.style.left = "-150px";
	}else if (MenuBody.style.left == "") {
		MenuBody.style.left = "-150px";
	}
	document.getElementById("Menu-Body").setAttribute("MovingRight", false);

    // Add event listeners for main Menu
	if (!isMobile) {
		MenuButton.addEventListener("mousedown", () => {
			moveItStart(MenuBody);
		});
		MenuPackage.addEventListener("mouseleave", () => {
			moveItEnd(MenuBody);
		});
	}else{
		MenuButton.addEventListener("mousedown", () => {
			MenuPopOpen(MenuBody); //Toggle the menu function here.
			MenuBody.setAttribute("isOpen",false);
		});
	}
	
    // Add child DIVs to MoveObjects and set event listeners

    Array.from(MenuBody.children).forEach(c => {
        if (c.tagName === "DIV") {
			c.id = "DIV_"+i;
            GlowObjects.push([c.id,0,.8]);
			document.getElementById(c.id).setAttribute("MovingRight", false);
			document.getElementById(c.id).setAttribute("Glowing", false);
			document.getElementById(c.id).setAttribute("GlowLevel", 0);
			document.getElementById(c.id).style.textShadow = "2px 2px 5px rgba(255, 255, 0, 0.0)";
            c.addEventListener("mouseover", () => {
				if (!isMobile) {
					moveItStart(c);
				}
            });
            c.addEventListener("mouseleave", () => {
				if (!isMobile) {
					moveItEnd(c);
				}
            });
			if (isNaN(c.style.left) == true) {
				c.style.left = "-155px";
			}else if (c.style.left == "") {
				c.style.left = "-155px";
			}
			i++;
        }
    });
	requestAnimationFrame(MoveIt);
}

// DeskTop Functionality
function MoveIt(){
	MenuBody = document.getElementById("Menu-Body");
	
	//console.log( parseInt(MenuBody.style.left));
	
	if ((MenuBody.getAttribute('MovingRight') == 'true') && (parseInt(MenuBody.style.left) <= 0)){
		MenuBody.style.left = (parseInt(MenuBody.style.left)+10) + "px";
	}else if ((MenuBody.getAttribute('MovingRight') == 'false') && (parseInt(MenuBody.style.left) >= -150)){
		MenuBody.style.left = (parseInt(MenuBody.style.left)-10) + "px";
	}
	requestAnimationFrame(MakeItGlow);
	requestAnimationFrame(MoveIt);
}

function MakeItGlow(){
	var Child;
	var GlowLevel; 
	
	GlowObjects.forEach(Arr => {
		Child = document.getElementById(Arr[0]);
		GlowLevel = Child.getAttribute('GlowLevel');
		Glowing = Child.getAttribute('Glowing');
		
		if (Child.getAttribute('MovingRight') == 'true'){//stopped here
			
		}else{
			
		}
	});
}

function moveItStart(e){
	document.getElementById(e.id).setAttribute("MovingRight", true);
}

function moveItEnd(e){
	document.getElementById(e.id).setAttribute("MovingRight", false);
}


//Mobile Functionality
function MenuPopOpen(e){
	
}

//Startup
MoveItSetup();