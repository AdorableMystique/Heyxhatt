<?php
/**
 * Häxhatten – PHP Framework
 * Copyright (C) 2026 Monica Hart
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

ini_set('display_errors', 1);
error_reporting(E_ALL);

global $code;

/*Tasks:
build template for Jodit Editor
Create Account App
Create file space app

*/

// Häxhatt by Monica Hart
// --Häxhatten fångar Loke (The witch's Hat captures Loki)
//-----------------------------------------------------------------------------
// Most PHP plugin systems trust third‑party code and try to recover at runtime. 
// I built a system that assumes every plugin is hostile and denies execution 
// unless it passes static and runtime policy checks.
//
// Enjoy Häxhatten - Monica Hart
//
// ©2026 Monica Hart

//basic commands object inherited by well... everything...
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once("AST.php"); //Load the AST Frame work
require_once("ErrorDefines.inc"); //Load the AST Frame work

class BaseClass{
    protected static array $Sections = [
            "Errors" => "",
            "Body" => "",
            "SideNav" => "",
            "TopNav" => "",
            "Footer" => "",
            "DocumentHeader" => "",
            "HTMLHeader" => "",
            "Meta" => "",
            "Title" => "",
            "ScriptsHeader" => "",
            "ScriptsBody" => "",
            "ScriptsFooter" => "",
            "Icon" => ""
    ];
    protected static array $URLParsed=[];
    protected static array $URLQuery=[];
    protected static bool $errorsInitialized = false;
    protected static array $errorList = [];
    protected static array $UI=[];
    protected static array $Config = [];
    protected static array $localizedErrorText = [];
    protected static string $defaultLang = 'en-US'; // fallback language
    protected static string $Blockmode="Blacklist";
    protected static array $BlockmodeList = [
    'PHP'  => [],
    'HTML' => [],
    'SQL'  => [],
    ];


    final protected static function processTemplate($Name){ //Sets the various templates other than the main template
        $failed=false;
        $folder="{$_SERVER['DOCUMENT_ROOT']}/Templates/";
        chmod($folder, 0755) ?? $failed=True;

        if ($failed==true){
            self::ErrorLog(ERROR_FILE_PERMISSIONS, 0755,$folder); //error out
            return false;
        }
        
        
        
        //self::ErrorLog(ERROR_FILE_PERMISSIONS, 0755,$folder); //error out
        $folder="{$_SERVER['DOCUMENT_ROOT']}/Templates/".$Name;


        if ($failed==false){

            if (self::$Config['System']['DevMode']==true){
                
                if (!file_exists("{$_SERVER['DOCUMENT_ROOT']}/Templates/".self::$Config['UI']['Default'])){
                    mkdir("{$_SERVER['DOCUMENT_ROOT']}/Templates/".self::$Config['UI']['Default']);
                }

                foreach(self::$Sections as $Key => $Value){
                    if (file_exists("{$folder}/{$Key}.tpl")){
                        self::$UI[$Key] = file_get_contents("{$folder}/{$Key}.tpl");
                    }else{//Create a Template
                        $code="<p id=\"".$Key."\">%".$Key."%</p>"; 
                        self::$UI[$Key] = $code;
                        file_put_contents("{$folder}/{$Key}.tpl",$code); // Create fresh template to work with.
                    }
                }
            }else{
                self::ErrorLog(ERROR_FILE_NOT_FOUND, "$folder}/{$Key}.tpl"); //error out
                return false;
            }
        }

        return True;
    }

    public static function boot(): void //In ze boot
    {

        $Config = parse_ini_file("{$_SERVER['DOCUMENT_ROOT']}/config.ini", true);
        self::$Config = $Config;
        self::$Blockmode=self::$Config['System']['Blockmode'];
        
        if ($Config === false) {
            self::ErrorLog(1, "config.ini", "Unable to parse configuration");
            return;
        }
        
        self::$URLParsed['page'] = parse_url($_SERVER['REQUEST_URI']);
        self::$URLParsed['address'] = parse_url($_SERVER['SERVER_NAME']);
        self::$URLParsed['https'] = parse_url($_SERVER['REQUEST_METHOD']);
        //self::$URLParsed = parse_url($_SERVER['REQUEST_URI']);
        parse_str($_SERVER['QUERY_STRING'] ?? '', self::$URLParsed['query']);

        self::$BlockmodeList = $Config['BlockmodeList'] ?? ['PHP'=>[], 'HTML'=>[], 'SQL'=>[]];
        self::$defaultLang=strtolower($Config['System']['DefaultLang']);

        $userTemplate['Name'] = $_SESSION['UI']['Default'] ?? self::$Config['UI']['Default'];

        switch (file_exists("{$_SERVER['DOCUMENT_ROOT']}/Templates/{$userTemplate['Name']}/index.html")){
            case true:
                self::$UI['mainTemplate']="{$_SERVER['DOCUMENT_ROOT']}/Templates/{$userTemplate['Name']}/index.html";
                break;
            default:

                if (file_exists("{$_SERVER['DOCUMENT_ROOT']}/Templates/".self::$Config['UI']['Default']."/index.html")){
                    self::$UI['mainTemplate']="{$_SERVER['DOCUMENT_ROOT']}/Templates/".self::$Config['UI']['Default']."/index.html";
                }else{

                    $defaultTemplate="<HTML><head></head><body>\n";
                    foreach(self::$Sections as $Key => $Value){
                        $defaultTemplate.="%{$Key}%\n";
                    }
                    $defaultTemplate.="\n</body></HTML>";
                    if (self::$Config['System']['DevMode']==false){
                        self::ErrorLog(1,$f1, "Cannot Load the default template and no user template found/defined");// no longer used
                        echo "Cannot Load the default template and no user template found/defined";
                        exit;
                    }else{
                        self::$UI['mainTemplate']=$defaultTemplate;
                        $failed=false;
                        if (!file_exists("{$_SERVER['DOCUMENT_ROOT']}/Templates/".self::$Config['UI']['Default'])){
                            mkdir("{$_SERVER['DOCUMENT_ROOT']}/Templates/".self::$Config['UI']['Default']);
                        }
                        if (file_exists("{$_SERVER['DOCUMENT_ROOT']}/Templates/".self::$Config['UI']['Default'])){
                            file_put_contents("{$_SERVER['DOCUMENT_ROOT']}/Templates/".self::$Config['UI']['Default']."/index.html",self::$UI['mainTemplate']);
                        }
                    }
                }
                break;
        }
        if (self::processTemplate($userTemplate['Name'])==false){//Stop execution due to fatal permission error
            exit;
        }

        foreach (self::$BlockmodeList as $k => $v) {
            if (is_string($v)) {
                self::$BlockmodeList[$k] = array_map('trim', explode(',', $v));
            } elseif (!is_array($v)) {
                self::$BlockmodeList[$k] = [];
            }
        }

    }

    protected static function initErrorList(){
        if (count(self::$errorList) > 0) {
            return; // already loaded
        }

        self::$errorsInitialized = true;

        if (file_exists("ErrorDefines.inc")){
            require_once("ErrorDefines.inc"); //not required it can run off numbers
        }

        $Lang=self::$defaultLang;
        if (class_exists('Locale') && isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
            $Lang = Locale::acceptFromHttp($_SERVER['HTTP_ACCEPT_LANGUAGE']);
        }

        $Lang=strtolower($Lang);
        $file="{$_SERVER['DOCUMENT_ROOT']}/localization/".self::$defaultLang."_error.txt";
        if (file_exists($file)){
           $errorList = file_get_contents($file);
        }else{
            error_log("FATAL: missing error localization file");
            exit(1);
        }
        
        if (file_exists("{$_SERVER['DOCUMENT_ROOT']}/localization/{$Lang}_error.txt")){ //Not fatal, the system will just resolve to the default error text
            $localizedErrorText= file_get_contents("{$_SERVER['DOCUMENT_ROOT']}/localization/{$Lang}_error.txt");
        }else{
            $localizedErrorText=$errorList;
        }

        self::$errorList=preg_split("/\r\n|\n|\r/", $errorList);//Error Log Text
        self::$localizedErrorText=preg_split("/\r\n|\n|\r/", $localizedErrorText);//For website output

    }

    final static function ErrorLog(){
        /*This is the error logging it should be used as BaseClass::ErrorLog,
          Appname::ErrorLog, followed by error name/number, and argumeents based
          on the number of arguments supporrted by the error string.*/
        self::initErrorList();
        if (func_num_args()<1){
            $ErrNo=2;
        }else{
            $ErrNo=func_get_arg(0);

        }
        $NewError = self::$errorList[$ErrNo-1] ?? "Unknown error ({$ErrNo})";
        $NewError2 = self::$localizedErrorText[$ErrNo-1] ?? "Unknown error ({$ErrNo})";
        $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2); //Get Debug info
        if (isset($trace[1])) {//check to see if there is a debug trace
            $caller = $trace[1];
            $function = isset($caller['function']) ? ", function: ".$caller['function'] : '';
            $class = isset($caller['class']) ? ", class: ".$caller['class'] : '';
            $file = isset($trace[1]['file']) ? $trace[1]['file'] : 'unknown file';
            $line = isset($trace[1]['line']) ? $trace[1]['line'] : 0;

            $ErrorInfo = "{$file}{$class}{$function}, on line {$line}";
            $NewError=str_ireplace("%ErrorInfo%",$ErrorInfo,$NewError);
            $NewError2=str_ireplace("%ErrorInfo%",$ErrorInfo,$NewError2);
            
        }

        if (func_num_args()>1){
            $Arguments=func_get_args();//Get the arguments
            unset($Arguments[0]);//remove the first argument from the array
            foreach($Arguments as $ArgumentID => $Value){
                $NewError=str_ireplace("%input{$ArgumentID}%",$Value,$NewError); //replace in order any value that follows this pattern %inputx% where x is a number starting at 1;
                $NewError2=str_ireplace("%input{$ArgumentID}%",$Value,$NewError2); //replace in order any value that follows this pattern %inputx% where x is a number starting at 1;
            }    
        }
        if (strlen(self::$Sections['Errors'])<2){
            self::$Sections['Errors']=$NewError2;
        }else{
            self::$Sections['Errors'].="\r\n<br/>{$NewError2}";
        }

        $err=str_ireplace("<b>","", $NewError); //striptags from the html for use in a text log
        $err=str_ireplace("</b>","",$err);//striptags from the html for use in a text log
        $err=str_ireplace("<br/>","",$err);//striptags from the html for use in a text log
        $err="[".date("m-d-y H:i:s")."] ".$err;//striptags from the html for use in a text log
        
        $logDir = __DIR__ . "/" . (self::$Config['System']['LogDir'] ?? 'logs');

        // make sure the directory exists
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true); // recursive mkdir with permissions
        }

        // write the log
        $errLog = $logDir . "/log_" . date("m-d-y") . ".log";
        file_put_contents($errLog, $err . PHP_EOL, FILE_APPEND);
    }

    final protected function DBConnect(){ 
        /*usaage create a config file in your object's root folder, 
        if one esxists it will automatically open the file and enter the information, 
        other wise it will use the default database*/

    }

    final protected function Query($script){ //usage script [options...] Returns requested data

    }

    //----------------------------------------AST Functions--------------------------------



    // needs test






    //scan for banned stuff
    final protected function ASTScanPHP(string $file): bool {

        Global $code;
        $code = file_get_contents($file);




        
        if ($code === false) {
            self::ErrorLog(ERROR_FILE_READ, $file);
            return true;
        }

        try {

            $commands = [];

            $version = max(ast\get_supported_versions());
            $ast = ast\parse_code($code, $version);

            $commands=extractCommands($ast, $commands); //extract function calls as a flat list in array and save in $commands.
        } catch (\Throwable $e) {
            self::ErrorLog(ERROR_PARSE_FAILED, $file, $e->getMessage());
            return true; // block if parsing fails
        }

        $violations = [];
        $denied=false;

        switch(self::$Blockmode){
            case "Blacklist":
                foreach($commands as $k => $v){                   
                    $v['Name']=strtolower($v['Name']);
                    if( in_array($v['Name'], self::$BlockmodeList['PHP']) == true ){//if in array Block it and count times used
                        if (isset($violations[$v['Name']])){
                            $violations[$v['Name']]['Count']++;
                        }else{
                            $violations[$v['Name']]['Count']=1;
                            $violations[$v['Name']]['Line']=array();
                        }
                        $violations[$v['Name']]['Line'][]=$v['Line'];
                        $denied=true;
                    }
                }
                break;
            case "Whitelist":
                foreach($commands as $k => $v){
                    $v['Name']=strtolower($v['Name']);
                    if( !in_array($v['Name'], self::$BlockmodeList['PHP']) == true ){//if in array Block it and count times used
                        if (isset($violations[$v['Name']])){
                            $violations[$v['Name']]['Count']++;
                        }else{
                            $violations[$v['Name']]=1;
                            $violations[$v['Name']]['Line']=array();
                        }
                        $violations[$v['Name']]['Line'][]=$v['Line'];
                        $denied=true;
                    }
                }
                break;
            default:
                //unknown block mode, fail the app
                $denied=true;
                self::ErrorLog(ERROR_INVALID_BLOCKMODE, $file, self::$Blockmode);
                break;
        }
        if (count($violations)>0){
            foreach($violations as $Name => $Violation){
                $lines = $Violation['Line'];  // copy the array
                sort($lines, SORT_NUMERIC);   // sort numerically (or as needed)
                $lines= implode(", ", $lines); // now it's a string
                self::ErrorLog(ERROR_APP_VIOLATION, $file, $Name, $Violation['Count'], $lines);
            }

        }
  

        //foreach ($violations as $v) {
            //self::ErrorLog(ERROR_FUNCTION_BLOCKED, "AST Kind not allowed: {$v['kind']}", $v['line'], $file);
       // }

        return $denied;
    }

    final protected function AppInstall($TarBall){ 
        /*Used to "trust" an app and moves the app from a tarball to an active apps folder and
        then runs various checks including an AI check before setting an INI to allow the script 
        to run. */

    }

    final protected function UpdateApps(){
        /*scans apps for new versions and then output a list of apps with new versions, with the
        current version and new version. Admins should make a concerted effort to read the files
        of the new */
    }

    final protected function RunScript($script){//usage script [options...] returns true or false 

    }
}

// Main Loop
class Häxhatten extends BaseClass{
    public static function boot(): void //In ze boot
    {
        //parent::boot();
    }

    function TSRLoop(){
        /*Not recommended as it asks the system to open a fork/process that stays open. It's more 
        resource intensive and less secure. Funcion works by creating a new named process/fork acessible 
        through a session key*/
    }


    function MainFunction(){
        /*this is the primary function*/
        $Config = parent::$Config;
        $dir = "{$_SERVER['DOCUMENT_ROOT']}/{$Config['System']['ApplicationsDirectory']}";
        if (is_dir($dir)) {
            $includes=scandir($dir);
            //return;
        }
   
        unset($includes[0],$includes[1]);
    
        foreach($includes as $Key => $Value){
            $file="{$dir}{$Value}";
            $filename_only = pathinfo($file, PATHINFO_FILENAME);
            $extension = pathinfo($file, PATHINFO_EXTENSION);
            $className = preg_replace('/[^a-zA-Z0-9_]/', '', $filename_only);


            if (!file_exists($file)||is_dir($file)||($extension !== "inc")){//Verify file...
                //Do nothing
            }else{
                


                $denied = self::ASTScanPHP($file);




                if ($denied==false){

                    $temp = str_replace('%Footer%', "Häxhatten – PHP Framework Copyright &copy; 2026 Monica Hart", parent::$UI['Footer']);
                    parent::$Sections['Footer'] .= $temp;

                    require_once($file);
                    foreach(parent::$Sections as $Key => $Value){
                       
                        ob_start();
                        if  ($Key=="Errors"){//do nothing
                        }elseif (class_exists($className) && method_exists($className, $Key)){
                            $OutString="";
                            $results = $className::$Key();
                            if (is_array($results)==false){
                                $OutString=$results;
                            }else{
                                $OutArray=$results;
                                $OutString="";
                            }
                            switch($Key){//This acts as the special filters.
                                case "Body":
                                    $temp = str_replace('%'.$Key.'%', $OutString, parent::$UI[$Key]);
                                    parent::$Sections[$Key] .= $temp; // append only the template result
                                    break;
                                case "SideNav":
                                    $OutString.=self::setOutputMenu($className, $Key, $OutArray);
                                    parent::$Sections[$Key].=$OutString;
                                    break;
                                case "TopNav":
                                    $OutString.=self::setOutputMenu($className, $Key, $OutArray);
                        
                                    //parent::$Sections[$Key].=$OutString;
                                    break;
                                case "Footer":
                                    $temp = str_replace('%'.$Key.'%', $OutString, parent::$UI[$Key]);
                                    parent::$Sections[$Key] .= $temp; // append only the template result
                                    break;
                                case "DocumentHeader":
                                    $temp = str_replace('%'.$Key.'%', $OutString, parent::$UI[$Key]);
                                    parent::$Sections[$Key] .= $temp; // append only the template result
                                    break;
                                case "HTMLHeader"://?? comine meta and header functions?
                                    $temp = str_replace('%'.$Key.'%', $OutString, parent::$UI[$Key]);
                                    parent::$Sections[$Key] .= $temp; // append only the template result
                                    break;;
                                case "Meta"://?? comine meta and header functions?
                                    $temp = str_replace('%'.$Key.'%', $OutString, parent::$UI[$Key]);
                                    parent::$Sections[$Key] .= $temp; // append only the template result
                                    break;
                                case "Title":
                                    $temp = str_replace('%'.$Key.'%', $OutString, parent::$UI[$Key]);
                                    parent::$Sections[$Key] .= $temp; // append only the template result
                                    break;
                                case "ScriptsHeader":// should return file names not scripts
                                    //Needs a scanner to avoid malicious/il-formed code
                                    //parent::BlackListFunctions($file,"JavaScript");
                                    break;
                                case "ScriptsBody":// should return file names not scripts
                                    //Needs a scanner to avoid malicious/il-formed code
                                    //parent::BlackListFunctions($file,"JavaScript");
                                    break;
                                case "ScriptsFooter":// should return file names not scripts
                                    //Needs a scanner to avoid malicious/il-formed code
                                    //parent::BlackListFunctions($file,"JavaScript");
                                    break;
                                default: //Unknown Section do an errror
                                    break;
                            }
                        }
                        $DebugStrings=ob_get_clean();

                        
                    }
                }else{
                    

                                    //print_r(self::$URLQuery);
                                    //exit;
                }
            }
        }
        $output = file_get_contents(parent::$UI['mainTemplate']);

        foreach(parent::$Sections as $Key => $Value){//set up the output
            $output = str_ireplace("%{$Key}%", $Value ?? "", $output);
        }
        echo $output; // output the final result
    }

    final private static function setOutputMenu($className, $Key, $inputArray){
        $OutString="";
        foreach($inputArray as $key => $Value){
            $OutString.=parent::$UI[$Key];
            foreach($Value as $k => $v){
                $OutString=str_ireplace("%input{$k}%",$v, $OutString);
            }
        }

        return $OutString;
    }
}

class application extends BaseClass{ 
    /*Acts as an application base, applications should be written as: 
    class <classname extends application{
    }
    */
    public static function Body(): string { return ''; }
    public static function SideNav(): array { return []; }
    public static function TopNav(): array { return []; }
    public static function Footer(): string { return ''; }
    public static function DocumentHeader(): string { return ''; }
    public static function HTMLHeader(): string { return ''; }
    public static function Meta(): string { return ''; }
    public static function Title(): string { return ''; }
    public static function ScriptsHeader(): array { return []; }
    public static function ScriptsBody(): array { return []; }
    public static function ScriptsFooter(): array { return []; }
}

interface RenderablePage {
    public static function Body(): string;
    public static function SideNav(): array;
    public static function TopNav(): array;
    public static function Footer(): string;
    public static function DocumentHeader(): string;
    public static function HTMLHeader(): string;
    public static function Meta(): string;
    public static function Title(): string;
    public static function ScriptsHeader(): array;
    public static function ScriptsBody(): array;
    public static function ScriptsFooter(): array;
}  

BaseClass::boot();
Häxhatten::boot(); // Not meant to be accessed by other objects
$hat = new Häxhatten();

$hat->MainFunction();
?>